If ever the GUI hangs in Genetic Algorithm, just wait for a bit. It's because of many generations being created in short amount of time for longer durations.
